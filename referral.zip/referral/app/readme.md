create a database and neame it as referal

Run migration using php artisan migrate